export class Applicant
{
    id: number
      fullName: string
      dateOfBirth:string
      highestQualification:string
      marksObtained:string
      goals:string
      emailId:string
      scheduledProgramId:number
      status:string
      dateOfInterview:string

      constructor(id,fullName,dateOfBirth,highestQualification,marksObtained,goals,emailId,scheduleProgramId,status,dateOfInterview)
      {
          this.id=id;
          this.fullName=fullName;
          this.dateOfBirth=dateOfBirth;
          this.highestQualification=highestQualification;
          this.marksObtained=marksObtained;
          this.goals=goals;
          this.emailId=emailId;
          this.scheduledProgramId=scheduleProgramId;
          this.status=status;
          this.dateOfInterview=dateOfInterview;
      }
}