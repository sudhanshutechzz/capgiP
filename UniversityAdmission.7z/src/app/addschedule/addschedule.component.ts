import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Applicant } from '../Applicant';
import { AppComponent } from '../app.component';
import { ProgramsScheduled } from '../ProgramsScheduled';

@Component({
  selector: 'app-addschedule',
  templateUrl: './addschedule.component.html',
  styleUrls: ['./addschedule.component.css']
})
export class AddscheduleComponent implements OnInit {

  array:ProgramsScheduled[]=[];
  postdata:ProgramsScheduled;
  spresp:any=[];
  success:boolean=false;
  message:string;
  remain:any=[];
  count:any;
  constructor(private service:DataService,private router:Router,public app:AppComponent) { }

  ngOnInit(): void {
   this.getCommon();
  }

  getCommon()
  {
    
   
    for(let i=0;i<this.app.course.length;i++)
    {
      this.count="0";
      for(let j=0;j<this.app.scheduledCourses.length;j++)
      {
        if(this.app.course[i].programName==this.app.scheduledCourses[j].programName)
        {
          this.count="10";
          
        }
           
      }
      
      if(this.count=="10")
      {
        }
      else
      {
      this.remain.push(this.app.course[i].programName);}
    }
    console.log(this.remain);
  }
  

  programsScheduledForm=new FormGroup({
    id:new FormControl,
    programName:new FormControl('',[Validators.required]),
    location:new FormControl('',[Validators.required]),
    startDate:new FormControl('',[Validators.required]),
    endDate:new FormControl('',[Validators.required]),
    sessionsPerWeek:new FormControl('',[Validators.required])
  })



  onSubmit()
  {
    if(this.programsScheduledForm.valid)
    {
    this. postdata=new ProgramsScheduled(0,this.programsScheduledForm.get("programName").value,this.programsScheduledForm.get("location").value,this.programsScheduledForm.get("startDate").value,this.programsScheduledForm.get("endDate").value,this.programsScheduledForm.get("sessionsPerWeek").value);
    this.success=true;
    this.message="Schedule is added successfully";
    
    this.service.addprogramScheduled(this.postdata).subscribe(resp=>{
      return this.spresp.push(resp);
    })
    this.router.navigateByUrl("/adds");
    }
  }


  logout()
  {
    this.router.navigateByUrl("login");
  }
}
