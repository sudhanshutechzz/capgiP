export class ProgramsScheduled
{
id:number
programName:string
location:string
startDate:string
endDate:string
sessionsPerWeek:string
constructor(id,programName,location,startDate,endDate,sessionsPerWeek)
{this.id=id;
    this.programName=programName;
    
    this.location=location;
    this.startDate=startDate;
    this.endDate=endDate;
    this.sessionsPerWeek=sessionsPerWeek;

}
}