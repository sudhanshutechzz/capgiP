import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewComponent } from './view/view.component';
import { LoginComponent } from './login/login.component';
import { AddcourseComponent } from './addcourse/addcourse.component';
import { AddscheduleComponent } from './addschedule/addschedule.component';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { DataService } from './data.service';
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { ViewscheduleComponent } from './viewschedule/viewschedule.component';
import { ViewapplicantComponent } from './viewapplicant/viewapplicant.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatListModule } from '@angular/material/list';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ErrorComponent } from './error/error.component';
import { MatDialogModule } from '@angular/material/dialog';



@NgModule({
  declarations: [
    AppComponent,
    ViewComponent,
    LoginComponent,
    AddcourseComponent,
    AddscheduleComponent,
    ViewcourseComponent,
    ViewscheduleComponent,
    ViewapplicantComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatButtonModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSelectModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
