import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ViewComponent } from '../view/view.component';
import { Router } from '@angular/router';
import { ProgramsOffered } from '../ProgramsOffered';

@Component({
  selector: 'app-addcourse',
  templateUrl: './addcourse.component.html',
  styleUrls: ['./addcourse.component.css']
})
export class AddcourseComponent implements OnInit {
  
  array:ProgramsOffered[]=[];
  postdata:ProgramsOffered;
  spresp:any=[];
  success:boolean=false;
  message:string;
  constructor(public service:DataService,public router:Router) { }

  ngOnInit(): void {
   // this.array=this.view.courses;
   this.service.getCourses().subscribe((data:any)=>{
    this.array=data;
  }
  )
  }
  programsOfferedForm=new FormGroup({
    id:new FormControl,
    programName:new FormControl('',[Validators.required]),
    applicantEligibility:new FormControl('',[Validators.required]),
    description:new FormControl('',[Validators.required]),
    duration:new FormControl('',[Validators.required]),
    degreeCertificateOffered:new FormControl('',[Validators.required])
  })
  onSubmit()
  { if(this.programsOfferedForm.valid)
    {
    let id=this.array[this.array.length-1].id+1;
    
    this. postdata=new ProgramsOffered(id,this.programsOfferedForm.get("programName").value,this.programsOfferedForm.get("applicantEligibility").value,this.programsOfferedForm.get("description").value,this.programsOfferedForm.get("duration").value,this.programsOfferedForm.get("degreeCertificateOffered").value);
    
    this.success=true;
    this.message="Course is added successfully and make sure you added the Schedule for the same Course";
    
    
    this.service.addprogramOffered(this.postdata).subscribe(resp=>{
      return this.spresp.push(resp);
    })
    this.router.navigateByUrl("/addc");
  }
}
  logout()
  {
    this.router.navigateByUrl("login");
  }
}
