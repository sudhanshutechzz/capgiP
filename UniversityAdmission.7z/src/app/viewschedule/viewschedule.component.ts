import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../data.service';
import { ProgramsScheduled } from '../ProgramsScheduled';


@Component({
  selector: 'app-viewschedule',
  templateUrl: './viewschedule.component.html',
  styleUrls: ['./viewschedule.component.css']
})
export class ViewscheduleComponent implements OnInit {
  scheduledCourses:ProgramsScheduled[]=[];
  spresp:any=[];
  success:boolean=false;
  message:string;
  constructor(public service:DataService,public router:Router) { }

  ngOnInit(): void {
    this.getScheduledCourses();
  }

  getScheduledCourses()
  {
    return this.service.getCourseSchedule().subscribe((data:any)=>{
      this.scheduledCourses=data;
    }
    )
  }
 
  onRemove1(id:any,programName:any)
  {
    this.success=true;
    this.message=programName +" Schedule is deleted successfully";
    for(let i=0;i<this.scheduledCourses.length;i++)
  {
    if(this.scheduledCourses[i].id==id)
    {
      this.scheduledCourses.splice(i,1);
    }
  }
    this.service.deleteScheduledCourse(id).subscribe(resp=>{
      return this.spresp.push(resp);
    })
    this.router.navigateByUrl("/views");
  }
  logout()
  {
    this.router.navigateByUrl("login");
  }
}
