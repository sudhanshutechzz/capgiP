export class ProgramsOffered
{
            id:number
            programName:string
            description:string
            applicantEligibility:string
            duration:string
            degreeCertificateOffered:string
            constructor(id,programName,description,applicantEligibility,duration,degreeCertificateOffered)

            {this.id=id;
                this.programName=programName;
                this.description=description;
                this.applicantEligibility=applicantEligibility;
                this.duration=duration;
                this.degreeCertificateOffered=degreeCertificateOffered;

            }
}