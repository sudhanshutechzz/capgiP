import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import {retry,catchError} from 'rxjs/operators';
import { Login } from './Login';
import { Applicant } from './Applicant';
import { ProgramsOffered } from './ProgramsOffered';
import { ProgramsScheduled } from './ProgramsScheduled';


@Injectable({
  providedIn: 'root'
})
export class DataService {
  localurl1:string="  http://localhost:3000/programsOffered";
  localurl2:string=" http://localhost:3000/programsScheduled";
  localurl3:string="  http://localhost:3000/users";
  localurl4:string=" http://localhost:3000/applicant";
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({'Content-Type':'application/json'})
  }
  getCourses():Observable<ProgramsOffered>
  {
    return this.http.get<ProgramsOffered>(this.localurl1)
    .pipe(retry(1),catchError(this.errorHandl))
  }
 
  getCourseSchedule():Observable<ProgramsScheduled>
  {
    return this.http.get<ProgramsScheduled>(this.localurl2)
    .pipe(retry(1),catchError(this.errorHandl))
  }
  getUsers():Observable<Login>
  {return this.http.get<Login>(this.localurl3)
    .pipe(retry(1),catchError(this.errorHandl))

  }
  getApplicant():Observable<Applicant>
  {
    return this.http.get<Applicant>(this.localurl4)
    .pipe(retry(1),catchError(this.errorHandl))
  }
 

  deleteCourses(id:any):Observable<ProgramsOffered>
  {
    return this.http.delete<ProgramsOffered>(this.localurl1+"/"+id,this.httpOptions)
    .pipe(retry(1),catchError(this.errorHandl))
  }
  deleteScheduledCourse(id:any):Observable<ProgramsScheduled>
  {
    return this.http.delete<ProgramsScheduled>(this.localurl2+"/"+id,this.httpOptions)
    .pipe(retry(1),catchError(this.errorHandl))
  }
  addprogramOffered(programsOffered:ProgramsOffered):Observable<ProgramsOffered>
  {
    return this.http.post<ProgramsOffered>(this.localurl1,programsOffered,this.httpOptions);
  }
  addprogramScheduled(programsScheduled:ProgramsScheduled):Observable<ProgramsScheduled>
  {
    return this.http.post<ProgramsScheduled>(this.localurl2,programsScheduled,this.httpOptions);
  }
  errorHandl(error)
  {
    console.log(error);
    return throwError(error);
  }
}
