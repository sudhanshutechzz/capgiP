import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Login } from '../Login';
import { Router } from '@angular/router';
import { ErrorComponent } from '../error/error.component';
import { MatDialog, MatDialogRef } from  '@angular/material/dialog';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  users:Login[]=[];
  count:any;
  constructor(public service:DataService,public router:Router,private  dialog:  MatDialog) { }

  ngOnInit(): void {
    this.getusers();

  }
  getusers()
  {
    return this.service.getUsers().subscribe((data:any)=>{
      this.users=data;
    }
    )
  }
  adminForm=new FormGroup({
    username:new FormControl,
    password:new FormControl,
    role:new FormControl
  })
  login()
  {
    for(let i=0;i<this.users.length;i++)
    {console.log(this.users);
      if(this.adminForm.get("username").value==this.users[i].userName && this.adminForm.get("password").value==this.users[i].password && this.adminForm.get("role").value==this.users[i].role)
      {
        this.count="1";
        
        break;
      
      }
      else
        {
          this.count="0";
          
           
        }
      }
       
        if(this.count=="1")
        { this.router.navigateByUrl("viewc");}
        else
        {this.dialog.open(ErrorComponent,{ data: {
          message:  "Your login information are incorrect!"
          }});

          
        }
    

  }

}
