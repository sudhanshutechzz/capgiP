import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Applicant } from '../Applicant';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { empty } from 'rxjs';
import { ProgramsOffered } from '../ProgramsOffered';

@Component({
  selector: 'app-viewapplicant',
  templateUrl: './viewapplicant.component.html',
  styleUrls: ['./viewapplicant.component.css']
})
export class ViewapplicantComponent implements OnInit {
  applicant:Applicant[]=[];
  course:ProgramsOffered[]=[];
  id:any;
  applicant2:Applicant[]=[];
  programName:any[]=["BBA","Btech","Mtech"];
  success2:boolean=false;
  success:boolean=false;
  message:string;
  count:string="0";
  constructor(public service:DataService,public router:Router) { }

  ngOnInit(): void {
    this.getApplicant();
    this.getCourse();
    
    
  }
  searchFilter = new FormControl('', Validators.required);

  getApplicant()
  {
    return this.service.getApplicant().subscribe((data:any)=>{
      this.applicant=data;
    }
    )
  }
  getCourse()
  {
    return  this.service.getCourses().subscribe((data:any)=>{
      this.course=data;
    })
  }


 
  logout()
  {
    this.router.navigateByUrl("login");
  }


  applySearchFilter()
  {
    this.success2=false;
    this.success=false;
    this.count="0";
    this.applicant2=[];
    for(let i=0;i<this.course.length;i++)
    {
      if(this.searchFilter.value.programName==this.course[i].programName)
      {
        this.id=this.course[i].id;
        break;
      }
    }
    for(let i=0;i<this.applicant.length;i++)
    {
      if(this.id==this.applicant[i].scheduledProgramId)
      {
        this.applicant2.push(this.applicant[i]);
        this.count="10";
      }
      else
      { this.message="No applicant is registred for this Program";
        
      }

    }
    if(this.count=="10")
    {
      this.success2=true;
    }
    else
    {
      this.success=true;
    }
  }

}
