import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddscheduleComponent } from './addschedule/addschedule.component';
import {AddcourseComponent} from './addcourse/addcourse.component';
import {ViewComponent} from './view/view.component';
import { LoginComponent } from './login/login.component';
import { ViewcourseComponent } from './viewcourse/viewcourse.component';
import { ViewscheduleComponent } from './viewschedule/viewschedule.component';
import { ViewapplicantComponent } from './viewapplicant/viewapplicant.component';
import { ErrorComponent } from './error/error.component';



const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot([
    {
      path:'view',component:ViewComponent},
      {
        path:'addc',component:AddcourseComponent},
        {
          path:'adds',component:AddscheduleComponent},
          {path:'login',component:LoginComponent},
          {path:'viewc',component:ViewcourseComponent},
          {path:'views',component:ViewscheduleComponent},
          {path:'viewa',component:ViewapplicantComponent},
          {path:'error',component:ErrorComponent}
        
  ])],
  exports: [RouterModule]
})
export class AppRoutingModule { }
