import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
import { Applicant } from '../Applicant';
import { ProgramsOffered } from '../ProgramsOffered';

@Component({
  selector: 'app-viewcourse',
  templateUrl: './viewcourse.component.html',
  styleUrls: ['./viewcourse.component.css']
})
export class ViewcourseComponent implements OnInit {
  courses:ProgramsOffered[]=[];
  spresp:any=[];
  applicant:Applicant[]=[];
  wait:any=0;
  accept:any;
  reject:any;
  success:boolean=false;
  success3:boolean=false;
  programName:any;
  total:any;
  courseName:any;
  success2:boolean=false;
  message:string;
  count:any;
  constructor(public service:DataService,public router:Router) { }

  ngOnInit(): void {
    this.getCourses();
    this.getApplicant();
    
  }
  getCourses()
  {
    return this.service.getCourses().subscribe((data:any)=>{
      this.courses=data;
    }
    )

  }
  getApplicant()
  {
    return this.service.getApplicant().subscribe((data:any)=>{
      this.applicant=data;
    }
    )
  }

  onRemove(id:any,programName:any)
  {
    for(let i=0;i<this.applicant.length;i++)
    {
      if(id==this.applicant[i].scheduledProgramId)
      {
        this.count="10";
      }
    }
    if(this.count==10)
    {
      this.success=false;
      this.success3=true;
      this.success2=false;
      this.message="Cannot delete the course because some students are enroll in it";}
    else
    {
    this.success2=true;
    this.success=false;
    this.success3=false;
    this.courseName=programName;
    this.message=programName + " deleted successfully and kindly make sure you will also delete the Schedule for "+ programName;
    for(let i=0;i<this.courses.length;i++)
  {
    if(this.courses[i].id==id)
    {
      this.courses.splice(i,1);
    }
  }
    this.service.deleteCourses(id).subscribe(resp=>{
      return this.spresp.push(resp);
    })
    this.router.navigateByUrl("/viewc");
  }
  }


  logout()
  {
    this.router.navigateByUrl("login");
  }



  getInfo(id:any,programName:any)
  {
    this.success2=false;
    this.success3=false;
    this.accept=0;
    this.reject=0;
    this.wait=0;
    this.total=0;
    this.success=true;
    for(let i=0;i<this.applicant.length;i++)
    {
      this.programName=programName;
    
      if(id==this.applicant[i].scheduledProgramId)
      {
        this.total++;

        if(this.applicant[i].status=="waiting")
        {
          this.wait++;
        }
        else if(this.applicant[i].status=="accepted")
        {
          this.accept++;
        }
        else if(this.applicant[i].status=="rejected")
        {
          this.reject++;
        }

      }
    }
   
  }

}
