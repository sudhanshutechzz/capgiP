package com.cg.UniversityAdmissionSystemApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.UniversityAdmissionSystemApp.model.LogIn;



public interface UsersRepository extends JpaRepository<LogIn, String> {

}
