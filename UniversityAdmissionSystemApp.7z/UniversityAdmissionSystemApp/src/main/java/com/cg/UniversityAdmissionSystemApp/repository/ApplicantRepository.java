package com.cg.UniversityAdmissionSystemApp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.UniversityAdmissionSystemApp.model.Applicant;



public interface ApplicantRepository extends JpaRepository<Applicant, Integer>{
Applicant save(Applicant applicant);
Optional<Applicant> findById(int id);
}
