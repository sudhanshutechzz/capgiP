package com.cg.UniversityAdmissionSystemApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.UniversityAdmissionSystemApp.model.Schedule;



public interface ScheduleReppository extends JpaRepository<Schedule, Integer> {

	Schedule save(Schedule schedule);
	 void deleteById(int id);
}
