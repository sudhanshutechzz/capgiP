package com.cg.UniversityAdmissionSystemApp.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="programs_scheduled")
public class Schedule {
	@Id
	@Column(name="Scheduled_program_id")
	private int Scheduled_program_id;
	@Column(name="program_name")
	private String programName; 
	@Column(name="loacation")
	private String Location;
	@Column(name="start_date")
	private String startDate;
	@Column(name="end_date")
	private String endDate ;
	@Column(name="sessions_per_week")
	private int sessionsPerWeek;
	public Schedule(){
		
	}
	public Schedule(int scheduled_program_id, String programName, String location, String startDate, String endDate,
			int sessionsPerWeek) {
		super();
		Scheduled_program_id = scheduled_program_id;
		this.programName = programName;
		Location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sessionsPerWeek = sessionsPerWeek;
	}
	public int getScheduled_program_id() {
		return Scheduled_program_id;
	}
	public void setScheduled_program_id(int scheduled_program_id) {
		Scheduled_program_id = scheduled_program_id;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getSessionsPerWeek() {
		return sessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.sessionsPerWeek = sessionsPerWeek;
	}
	@Override
	public String toString() {
		return "Schedule [Scheduled_program_id=" + Scheduled_program_id + ", programName=" + programName + ", Location="
				+ Location + ", startDate=" + startDate + ", endDate=" + endDate + ", sessionsPerWeek="
				+ sessionsPerWeek + "]";
	}
	
}
