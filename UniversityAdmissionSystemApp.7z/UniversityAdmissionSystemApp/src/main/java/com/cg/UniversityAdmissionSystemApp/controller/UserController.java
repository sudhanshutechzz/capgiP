package com.cg.UniversityAdmissionSystemApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.UniversityAdmissionSystemApp.model.Applicant;
import com.cg.UniversityAdmissionSystemApp.model.Courses;
import com.cg.UniversityAdmissionSystemApp.model.LogIn;
import com.cg.UniversityAdmissionSystemApp.model.Schedule;
import com.cg.UniversityAdmissionSystemApp.service.AdminService;



@CrossOrigin(origins = "http://localhost:4200")	
@RestController
public class UserController {
	
@Autowired
AdminService service;

@GetMapping(value="/userList", produces="application/json")	
public List<LogIn> getUserList()
	{
		List<LogIn> userList=null;
		
		userList=service.getUsers();
		
		return userList;
	}

@GetMapping(value="/applicantList", produces="application/json")	
public List<Applicant> getApplicantList()
	{
		List<Applicant> applicantList=null;
		
		applicantList=service.getApplicant();
		
		return applicantList;
	}

@GetMapping(value="/courseList", produces="application/json")	
public List<Courses> getCourseList()
	{
		List<Courses> courseList=null;
		
		courseList=service.getCourses();
		
		return courseList;
	}

@PostMapping(value="/courseList", consumes="application/json" ,produces="application/json")
public Courses addCourse(@RequestBody Courses courses)
{
	return service.addCourse(courses);
}

@DeleteMapping(path ={"/courseList/{id}"})
public void deleteCourse(@PathVariable("id") int id) {
    service.deleteById(id);
}

@GetMapping(value="/scheduleList", produces="application/json")	
public List<Schedule> getScheduleList()
	{
		List<Schedule> scheduleList=null;
		
		scheduleList=service.getSchedule();
		
		return scheduleList;
	}

@PostMapping(value="/scheduleList", consumes="application/json" ,produces="application/json")
public Schedule addSchedule(@RequestBody Schedule schedule)
{
	return service.addSchedule(schedule);
}

@DeleteMapping(path ={"/scheduleList/{id}"})
public void deleteSchedule(@PathVariable("id") int id) {
    service.deleteById(id);
}








}
