package com.cg.UniversityAdmissionSystemApp.service;

import java.util.List;

import com.cg.UniversityAdmissionSystemApp.model.Applicant;
import com.cg.UniversityAdmissionSystemApp.model.Courses;
import com.cg.UniversityAdmissionSystemApp.model.LogIn;
import com.cg.UniversityAdmissionSystemApp.model.Schedule;




public interface AdminService {
	public List<LogIn> getUsers();
	public List<Applicant> getApplicant();
	public List<Courses> getCourses();
	public Courses addCourse(Courses course);
	public void deleteById(int id);
	public List<Schedule> getSchedule();
	public Schedule addSchedule(Schedule sch);
	public void deleteByIdSchedule(int id);
}
