package com.cg.UniversityAdmissionSystemApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.UniversityAdmissionSystemApp.model.Courses;



public interface CoursesRepository extends JpaRepository<Courses, Integer>{
	
	Courses save(Courses course);
	 void deleteById(int id);

	


}
