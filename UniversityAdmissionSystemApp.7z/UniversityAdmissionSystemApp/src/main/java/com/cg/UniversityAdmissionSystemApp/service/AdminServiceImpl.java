package com.cg.UniversityAdmissionSystemApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.UniversityAdmissionSystemApp.model.Applicant;
import com.cg.UniversityAdmissionSystemApp.model.Courses;
import com.cg.UniversityAdmissionSystemApp.model.LogIn;
import com.cg.UniversityAdmissionSystemApp.model.Schedule;
import com.cg.UniversityAdmissionSystemApp.repository.ApplicantRepository;
import com.cg.UniversityAdmissionSystemApp.repository.CoursesRepository;
import com.cg.UniversityAdmissionSystemApp.repository.ScheduleReppository;
import com.cg.UniversityAdmissionSystemApp.repository.UsersRepository;


@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	CoursesRepository courses;
	@Autowired 
	ScheduleReppository schedule;
	@Autowired 
	ApplicantRepository applicant;
	@Autowired
	UsersRepository users;
	
	public List<LogIn> getUsers()
	{
		return users.findAll();
		
	}
	public List<Applicant> getApplicant()
	{
		return applicant.findAll();
		
	}

	public List<Courses> getCourses()
	{
		return courses.findAll();
		
	}

	public Courses addCourse(Courses course)
	{
		return courses.save(course);
	}
	public void deleteById(int id) {
	    courses.deleteById(id);
	}

	public List<Schedule> getSchedule()
	{
		return schedule.findAll();
		
	}

	public Schedule addSchedule(Schedule sch)
	{
		return schedule.save(sch);
	}

	public void deleteByIdSchedule(int id) {
	    schedule.deleteById(id);
	}
}
