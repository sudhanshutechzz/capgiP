package com.cg.UniversityAdmissionSystemApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniversityAdmissionSystemAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
